## BDS Helper
A basic add-on to help shoppers know whether a company should be boycotted for supporting Israel's illegal occupation of Palestine and abuse of human rights.
This extension is a work-in-progress. More features will be added in time.

## Thanks
Icons provided free by [EmojiOne](http://emojione.com/)

## License
[MIT](https://github.com/muzilos/ethical-shopper-firefox-extension/blob/master/LICENSE)